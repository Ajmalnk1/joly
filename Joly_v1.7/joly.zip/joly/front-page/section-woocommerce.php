<?php
$joly_woocommerce_sc = joly_get_theme_option( 'front_page_woocommerce_products' );
if ( ! empty( $joly_woocommerce_sc ) ) {
	?><div class="front_page_section front_page_section_woocommerce<?php
		$joly_scheme = joly_get_theme_option( 'front_page_woocommerce_scheme' );
		if ( ! empty( $joly_scheme ) && ! joly_is_inherit( $joly_scheme ) ) {
			echo ' scheme_' . esc_attr( $joly_scheme );
		}
		echo ' front_page_section_paddings_' . esc_attr( joly_get_theme_option( 'front_page_woocommerce_paddings' ) );
		if ( joly_get_theme_option( 'front_page_woocommerce_stack' ) ) {
			echo ' sc_stack_section_on';
		}
	?>"
			<?php
			$joly_css      = '';
			$joly_bg_image = joly_get_theme_option( 'front_page_woocommerce_bg_image' );
			if ( ! empty( $joly_bg_image ) ) {
				$joly_css .= 'background-image: url(' . esc_url( joly_get_attachment_url( $joly_bg_image ) ) . ');';
			}
			if ( ! empty( $joly_css ) ) {
				echo ' style="' . esc_attr( $joly_css ) . '"';
			}
			?>
	>
	<?php
		// Add anchor
		$joly_anchor_icon = joly_get_theme_option( 'front_page_woocommerce_anchor_icon' );
		$joly_anchor_text = joly_get_theme_option( 'front_page_woocommerce_anchor_text' );
		if ( ( ! empty( $joly_anchor_icon ) || ! empty( $joly_anchor_text ) ) && shortcode_exists( 'trx_sc_anchor' ) ) {
			echo do_shortcode(
				'[trx_sc_anchor id="front_page_section_woocommerce"'
											. ( ! empty( $joly_anchor_icon ) ? ' icon="' . esc_attr( $joly_anchor_icon ) . '"' : '' )
											. ( ! empty( $joly_anchor_text ) ? ' title="' . esc_attr( $joly_anchor_text ) . '"' : '' )
											. ']'
			);
		}
	?>
		<div class="front_page_section_inner front_page_section_woocommerce_inner
			<?php
			if ( joly_get_theme_option( 'front_page_woocommerce_fullheight' ) ) {
				echo ' joly-full-height sc_layouts_flex sc_layouts_columns_middle';
			}
			?>
				"
				<?php
				$joly_css      = '';
				$joly_bg_mask  = joly_get_theme_option( 'front_page_woocommerce_bg_mask' );
				$joly_bg_color_type = joly_get_theme_option( 'front_page_woocommerce_bg_color_type' );
				if ( 'custom' == $joly_bg_color_type ) {
					$joly_bg_color = joly_get_theme_option( 'front_page_woocommerce_bg_color' );
				} elseif ( 'scheme_bg_color' == $joly_bg_color_type ) {
					$joly_bg_color = joly_get_scheme_color( 'bg_color', $joly_scheme );
				} else {
					$joly_bg_color = '';
				}
				if ( ! empty( $joly_bg_color ) && $joly_bg_mask > 0 ) {
					$joly_css .= 'background-color: ' . esc_attr(
						1 == $joly_bg_mask ? $joly_bg_color : joly_hex2rgba( $joly_bg_color, $joly_bg_mask )
					) . ';';
				}
				if ( ! empty( $joly_css ) ) {
					echo ' style="' . esc_attr( $joly_css ) . '"';
				}
				?>
		>
			<div class="front_page_section_content_wrap front_page_section_woocommerce_content_wrap content_wrap woocommerce">
				<?php
				// Content wrap with title and description
				$joly_caption     = joly_get_theme_option( 'front_page_woocommerce_caption' );
				$joly_description = joly_get_theme_option( 'front_page_woocommerce_description' );
				if ( ! empty( $joly_caption ) || ! empty( $joly_description ) || ( current_user_can( 'edit_theme_options' ) && is_customize_preview() ) ) {
					// Caption
					if ( ! empty( $joly_caption ) || ( current_user_can( 'edit_theme_options' ) && is_customize_preview() ) ) {
						?>
						<h2 class="front_page_section_caption front_page_section_woocommerce_caption front_page_block_<?php echo ! empty( $joly_caption ) ? 'filled' : 'empty'; ?>">
						<?php
							echo wp_kses( $joly_caption, 'joly_kses_content' );
						?>
						</h2>
						<?php
					}

					// Description (text)
					if ( ! empty( $joly_description ) || ( current_user_can( 'edit_theme_options' ) && is_customize_preview() ) ) {
						?>
						<div class="front_page_section_description front_page_section_woocommerce_description front_page_block_<?php echo ! empty( $joly_description ) ? 'filled' : 'empty'; ?>">
						<?php
							echo wp_kses( wpautop( $joly_description ), 'joly_kses_content' );
						?>
						</div>
						<?php
					}
				}

				// Content (widgets)
				?>
				<div class="front_page_section_output front_page_section_woocommerce_output list_products shop_mode_thumbs">
					<?php
					if ( 'products' == $joly_woocommerce_sc ) {
						$joly_woocommerce_sc_ids      = joly_get_theme_option( 'front_page_woocommerce_products_per_page' );
						$joly_woocommerce_sc_per_page = count( explode( ',', $joly_woocommerce_sc_ids ) );
					} else {
						$joly_woocommerce_sc_per_page = max( 1, (int) joly_get_theme_option( 'front_page_woocommerce_products_per_page' ) );
					}
					$joly_woocommerce_sc_columns = max( 1, min( $joly_woocommerce_sc_per_page, (int) joly_get_theme_option( 'front_page_woocommerce_products_columns' ) ) );
					echo do_shortcode(
						"[{$joly_woocommerce_sc}"
										. ( 'products' == $joly_woocommerce_sc
												? ' ids="' . esc_attr( $joly_woocommerce_sc_ids ) . '"'
												: '' )
										. ( 'product_category' == $joly_woocommerce_sc
												? ' category="' . esc_attr( joly_get_theme_option( 'front_page_woocommerce_products_categories' ) ) . '"'
												: '' )
										. ( 'best_selling_products' != $joly_woocommerce_sc
												? ' orderby="' . esc_attr( joly_get_theme_option( 'front_page_woocommerce_products_orderby' ) ) . '"'
													. ' order="' . esc_attr( joly_get_theme_option( 'front_page_woocommerce_products_order' ) ) . '"'
												: '' )
										. ' per_page="' . esc_attr( $joly_woocommerce_sc_per_page ) . '"'
										. ' columns="' . esc_attr( $joly_woocommerce_sc_columns ) . '"'
						. ']'
					);
					?>
				</div>
			</div>
		</div>
	</div>
	<?php
}
