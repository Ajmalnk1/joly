<div class="front_page_section front_page_section_features<?php
	$joly_scheme = joly_get_theme_option( 'front_page_features_scheme' );
	if ( ! empty( $joly_scheme ) && ! joly_is_inherit( $joly_scheme ) ) {
		echo ' scheme_' . esc_attr( $joly_scheme );
	}
	echo ' front_page_section_paddings_' . esc_attr( joly_get_theme_option( 'front_page_features_paddings' ) );
	if ( joly_get_theme_option( 'front_page_features_stack' ) ) {
		echo ' sc_stack_section_on';
	}
?>"
		<?php
		$joly_css      = '';
		$joly_bg_image = joly_get_theme_option( 'front_page_features_bg_image' );
		if ( ! empty( $joly_bg_image ) ) {
			$joly_css .= 'background-image: url(' . esc_url( joly_get_attachment_url( $joly_bg_image ) ) . ');';
		}
		if ( ! empty( $joly_css ) ) {
			echo ' style="' . esc_attr( $joly_css ) . '"';
		}
		?>
>
<?php
	// Add anchor
	$joly_anchor_icon = joly_get_theme_option( 'front_page_features_anchor_icon' );
	$joly_anchor_text = joly_get_theme_option( 'front_page_features_anchor_text' );
if ( ( ! empty( $joly_anchor_icon ) || ! empty( $joly_anchor_text ) ) && shortcode_exists( 'trx_sc_anchor' ) ) {
	echo do_shortcode(
		'[trx_sc_anchor id="front_page_section_features"'
									. ( ! empty( $joly_anchor_icon ) ? ' icon="' . esc_attr( $joly_anchor_icon ) . '"' : '' )
									. ( ! empty( $joly_anchor_text ) ? ' title="' . esc_attr( $joly_anchor_text ) . '"' : '' )
									. ']'
	);
}
?>
	<div class="front_page_section_inner front_page_section_features_inner
	<?php
	if ( joly_get_theme_option( 'front_page_features_fullheight' ) ) {
		echo ' joly-full-height sc_layouts_flex sc_layouts_columns_middle';
	}
	?>
			"
			<?php
			$joly_css      = '';
			$joly_bg_mask  = joly_get_theme_option( 'front_page_features_bg_mask' );
			$joly_bg_color_type = joly_get_theme_option( 'front_page_features_bg_color_type' );
			if ( 'custom' == $joly_bg_color_type ) {
				$joly_bg_color = joly_get_theme_option( 'front_page_features_bg_color' );
			} elseif ( 'scheme_bg_color' == $joly_bg_color_type ) {
				$joly_bg_color = joly_get_scheme_color( 'bg_color', $joly_scheme );
			} else {
				$joly_bg_color = '';
			}
			if ( ! empty( $joly_bg_color ) && $joly_bg_mask > 0 ) {
				$joly_css .= 'background-color: ' . esc_attr(
					1 == $joly_bg_mask ? $joly_bg_color : joly_hex2rgba( $joly_bg_color, $joly_bg_mask )
				) . ';';
			}
			if ( ! empty( $joly_css ) ) {
				echo ' style="' . esc_attr( $joly_css ) . '"';
			}
			?>
	>
		<div class="front_page_section_content_wrap front_page_section_features_content_wrap content_wrap">
			<?php
			// Caption
			$joly_caption = joly_get_theme_option( 'front_page_features_caption' );
			if ( ! empty( $joly_caption ) || ( current_user_can( 'edit_theme_options' ) && is_customize_preview() ) ) {
				?>
				<h2 class="front_page_section_caption front_page_section_features_caption front_page_block_<?php echo ! empty( $joly_caption ) ? 'filled' : 'empty'; ?>"><?php echo wp_kses( $joly_caption, 'joly_kses_content' ); ?></h2>
				<?php
			}

			// Description (text)
			$joly_description = joly_get_theme_option( 'front_page_features_description' );
			if ( ! empty( $joly_description ) || ( current_user_can( 'edit_theme_options' ) && is_customize_preview() ) ) {
				?>
				<div class="front_page_section_description front_page_section_features_description front_page_block_<?php echo ! empty( $joly_description ) ? 'filled' : 'empty'; ?>"><?php echo wp_kses( wpautop( $joly_description ), 'joly_kses_content' ); ?></div>
				<?php
			}

			// Content (widgets)
			?>
			<div class="front_page_section_output front_page_section_features_output">
				<?php
				if ( is_active_sidebar( 'front_page_features_widgets' ) ) {
					dynamic_sidebar( 'front_page_features_widgets' );
				} elseif ( current_user_can( 'edit_theme_options' ) ) {
					if ( ! joly_exists_trx_addons() ) {
						joly_customizer_need_trx_addons_message();
					} else {
						joly_customizer_need_widgets_message( 'front_page_features_caption', 'ThemeREX Addons - Services' );
					}
				}
				?>
			</div>
		</div>
	</div>
</div>
