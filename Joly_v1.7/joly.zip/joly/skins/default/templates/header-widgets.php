<?php
/**
 * The template to display the widgets area in the header
 *
 * @package JOLY
 * @since JOLY 1.0
 */

// Header sidebar
$joly_header_name    = joly_get_theme_option( 'header_widgets' );
$joly_header_present = ! joly_is_off( $joly_header_name ) && is_active_sidebar( $joly_header_name );
if ( $joly_header_present ) {
	joly_storage_set( 'current_sidebar', 'header' );
	$joly_header_wide = joly_get_theme_option( 'header_wide' );
	ob_start();
	if ( is_active_sidebar( $joly_header_name ) ) {
		dynamic_sidebar( $joly_header_name );
	}
	$joly_widgets_output = ob_get_contents();
	ob_end_clean();
	if ( ! empty( $joly_widgets_output ) ) {
		$joly_widgets_output = preg_replace( "/<\/aside>[\r\n\s]*<aside/", '</aside><aside', $joly_widgets_output );
		$joly_need_columns   = strpos( $joly_widgets_output, 'columns_wrap' ) === false;
		if ( $joly_need_columns ) {
			$joly_columns = max( 0, (int) joly_get_theme_option( 'header_columns' ) );
			if ( 0 == $joly_columns ) {
				$joly_columns = min( 6, max( 1, joly_tags_count( $joly_widgets_output, 'aside' ) ) );
			}
			if ( $joly_columns > 1 ) {
				$joly_widgets_output = preg_replace( '/<aside([^>]*)class="widget/', '<aside$1class="column-1_' . esc_attr( $joly_columns ) . ' widget', $joly_widgets_output );
			} else {
				$joly_need_columns = false;
			}
		}
		?>
		<div class="header_widgets_wrap widget_area<?php echo ! empty( $joly_header_wide ) ? ' header_fullwidth' : ' header_boxed'; ?>">
			<?php do_action( 'joly_action_before_sidebar_wrap', 'header' ); ?>
			<div class="header_widgets_inner widget_area_inner">
				<?php
				if ( ! $joly_header_wide ) {
					?>
					<div class="content_wrap">
					<?php
				}
				if ( $joly_need_columns ) {
					?>
					<div class="columns_wrap">
					<?php
				}
				do_action( 'joly_action_before_sidebar', 'header' );
				joly_show_layout( $joly_widgets_output );
				do_action( 'joly_action_after_sidebar', 'header' );
				if ( $joly_need_columns ) {
					?>
					</div>	<!-- /.columns_wrap -->
					<?php
				}
				if ( ! $joly_header_wide ) {
					?>
					</div>	<!-- /.content_wrap -->
					<?php
				}
				?>
			</div>	<!-- /.header_widgets_inner -->
			<?php do_action( 'joly_action_after_sidebar_wrap', 'header' ); ?>
		</div>	<!-- /.header_widgets_wrap -->
		<?php
	}
}
