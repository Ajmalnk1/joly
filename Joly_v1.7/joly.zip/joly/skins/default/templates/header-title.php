<?php
/**
 * The template to display the page title and breadcrumbs
 *
 * @package JOLY
 * @since JOLY 1.0
 */

// Page (category, tag, archive, author) title

if ( joly_need_page_title() ) {
	joly_sc_layouts_showed( 'title', true );
	joly_sc_layouts_showed( 'postmeta', true );
	?>
	<div class="top_panel_title sc_layouts_row sc_layouts_row_type_normal">
		<div class="content_wrap">
			<div class="sc_layouts_column sc_layouts_column_align_center">
				<div class="sc_layouts_item">
					<div class="sc_layouts_title sc_align_center">
						<?php
						// Post meta on the single post
						if ( is_single() ) {
							?>
							<div class="sc_layouts_title_meta">
							<?php
								joly_show_post_meta(
									apply_filters(
										'joly_filter_post_meta_args', array(
											'components' => join( ',', joly_array_get_keys_by_value( joly_get_theme_option( 'meta_parts' ) ) ),
											'counters'   => join( ',', joly_array_get_keys_by_value( joly_get_theme_option( 'counters' ) ) ),
											'seo'        => joly_is_on( joly_get_theme_option( 'seo_snippets' ) ),
										), 'header', 1
									)
								);
							?>
							</div>
							<?php
						}

						// Blog/Post title
						?>
						<div class="sc_layouts_title_title">
							<?php
							$joly_blog_title           = joly_get_blog_title();
							$joly_blog_title_text      = '';
							$joly_blog_title_class     = '';
							$joly_blog_title_link      = '';
							$joly_blog_title_link_text = '';
							if ( is_array( $joly_blog_title ) ) {
								$joly_blog_title_text      = $joly_blog_title['text'];
								$joly_blog_title_class     = ! empty( $joly_blog_title['class'] ) ? ' ' . $joly_blog_title['class'] : '';
								$joly_blog_title_link      = ! empty( $joly_blog_title['link'] ) ? $joly_blog_title['link'] : '';
								$joly_blog_title_link_text = ! empty( $joly_blog_title['link_text'] ) ? $joly_blog_title['link_text'] : '';
							} else {
								$joly_blog_title_text = $joly_blog_title;
							}
							?>
							<h1 itemprop="headline" class="sc_layouts_title_caption<?php echo esc_attr( $joly_blog_title_class ); ?>">
								<?php
								$joly_top_icon = joly_get_term_image_small();
								if ( ! empty( $joly_top_icon ) ) {
									$joly_attr = joly_getimagesize( $joly_top_icon );
									?>
									<img src="<?php echo esc_url( $joly_top_icon ); ?>" alt="<?php esc_attr_e( 'Site icon', 'joly' ); ?>"
										<?php
										if ( ! empty( $joly_attr[3] ) ) {
											joly_show_layout( $joly_attr[3] );
										}
										?>
									>
									<?php
								}
								echo wp_kses_data( $joly_blog_title_text );
								?>
							</h1>
							<?php
							if ( ! empty( $joly_blog_title_link ) && ! empty( $joly_blog_title_link_text ) ) {
								?>
								<a href="<?php echo esc_url( $joly_blog_title_link ); ?>" class="theme_button theme_button_small sc_layouts_title_link"><?php echo esc_html( $joly_blog_title_link_text ); ?></a>
								<?php
							}

							// Category/Tag description
							if ( ! is_paged() && ( is_category() || is_tag() || is_tax() ) ) {
								the_archive_description( '<div class="sc_layouts_title_description">', '</div>' );
							}

							?>
						</div>
						<?php

						// Breadcrumbs
						ob_start();
						do_action( 'joly_action_breadcrumbs' );
						$joly_breadcrumbs = ob_get_contents();
						ob_end_clean();
						joly_show_layout( $joly_breadcrumbs, '<div class="sc_layouts_title_breadcrumbs">', '</div>' );
						?>
					</div>
				</div>
			</div>
		</div>
	</div>
	<?php
}
