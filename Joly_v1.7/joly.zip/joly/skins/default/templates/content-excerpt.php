<?php
/**
 * The default template to display the content
 *
 * Used for index/archive/search.
 *
 * @package JOLY
 * @since JOLY 1.0
 */

$joly_template_args = get_query_var( 'joly_template_args' );
$joly_columns = 1;
if ( is_array( $joly_template_args ) ) {
	$joly_columns    = empty( $joly_template_args['columns'] ) ? 1 : max( 1, $joly_template_args['columns'] );
	$joly_blog_style = array( $joly_template_args['type'], $joly_columns );
	if ( ! empty( $joly_template_args['slider'] ) ) {
		?><div class="slider-slide swiper-slide">
		<?php
	} elseif ( $joly_columns > 1 ) {
	    $joly_columns_class = joly_get_column_class( 1, $joly_columns, ! empty( $joly_template_args['columns_tablet']) ? $joly_template_args['columns_tablet'] : '', ! empty($joly_template_args['columns_mobile']) ? $joly_template_args['columns_mobile'] : '' );
		?>
		<div class="<?php echo esc_attr( $joly_columns_class ); ?>">
		<?php
	}
}
$joly_expanded    = ! joly_sidebar_present() && joly_get_theme_option( 'expand_content' ) == 'expand';
$joly_post_format = get_post_format();
$joly_post_format = empty( $joly_post_format ) ? 'standard' : str_replace( 'post-format-', '', $joly_post_format );
?>
<article id="post-<?php the_ID(); ?>" data-post-id="<?php the_ID(); ?>"
	<?php
	post_class( 'post_item post_item_container post_layout_excerpt post_format_' . esc_attr( $joly_post_format ) );
	joly_add_blog_animation( $joly_template_args );
	?>
>
	<?php

	// Sticky label
	if ( is_sticky() && ! is_paged() ) {
		?>
		<span class="post_label label_sticky"></span>
		<?php
	}

	// Featured image
	$joly_hover      = ! empty( $joly_template_args['hover'] ) && ! joly_is_inherit( $joly_template_args['hover'] )
							? $joly_template_args['hover']
							: joly_get_theme_option( 'image_hover' );
	$joly_components = ! empty( $joly_template_args['meta_parts'] )
							? ( is_array( $joly_template_args['meta_parts'] )
								? $joly_template_args['meta_parts']
								: array_map( 'trim', explode( ',', $joly_template_args['meta_parts'] ) )
								)
							: joly_array_get_keys_by_value( joly_get_theme_option( 'meta_parts' ) );
	joly_show_post_featured( apply_filters( 'joly_filter_args_featured',
		array(
			'no_links'   => ! empty( $joly_template_args['no_links'] ),
			'hover'      => $joly_hover,
			'meta_parts' => $joly_components,
			'thumb_size' => ! empty( $joly_template_args['thumb_size'] )
							? $joly_template_args['thumb_size']
							: joly_get_thumb_size( strpos( joly_get_theme_option( 'body_style' ), 'full' ) !== false
								? 'full'
								: ( $joly_expanded 
									? 'huge' 
									: 'big' 
									)
								),
		),
		'content-excerpt',
		$joly_template_args
	) );

	// Title and post meta
	$joly_show_title = get_the_title() != '';
	$joly_show_meta  = count( $joly_components ) > 0 && ! in_array( $joly_hover, array( 'border', 'pull', 'slide', 'fade', 'info' ) );

	if ( $joly_show_title ) {
		?>
		<div class="post_header entry-header">
			<?php
			// Post title
			if ( apply_filters( 'joly_filter_show_blog_title', true, 'excerpt' ) ) {
				do_action( 'joly_action_before_post_title' );
				if ( empty( $joly_template_args['no_links'] ) ) {
					the_title( sprintf( '<h3 class="post_title entry-title"><a href="%s" rel="bookmark">', esc_url( get_permalink() ) ), '</a></h3>' );
				} else {
					the_title( '<h3 class="post_title entry-title">', '</h3>' );
				}
				do_action( 'joly_action_after_post_title' );
			}
			?>
		</div><!-- .post_header -->
		<?php
	}

	// Post content
	if ( apply_filters( 'joly_filter_show_blog_excerpt', empty( $joly_template_args['hide_excerpt'] ) && joly_get_theme_option( 'excerpt_length' ) > 0, 'excerpt' ) ) {
		?>
		<div class="post_content entry-content">
			<?php

			// Post meta
			if ( apply_filters( 'joly_filter_show_blog_meta', $joly_show_meta, $joly_components, 'excerpt' ) ) {
				if ( count( $joly_components ) > 0 ) {
					do_action( 'joly_action_before_post_meta' );
					joly_show_post_meta(
						apply_filters(
							'joly_filter_post_meta_args', array(
								'components' => join( ',', $joly_components ),
								'seo'        => false,
								'echo'       => true,
							), 'excerpt', 1
						)
					);
					do_action( 'joly_action_after_post_meta' );
				}
			}

			if ( joly_get_theme_option( 'blog_content' ) == 'fullpost' ) {
				// Post content area
				?>
				<div class="post_content_inner">
					<?php
					do_action( 'joly_action_before_full_post_content' );
					the_content( '' );
					do_action( 'joly_action_after_full_post_content' );
					?>
				</div>
				<?php
				// Inner pages
				wp_link_pages(
					array(
						'before'      => '<div class="page_links"><span class="page_links_title">' . esc_html__( 'Pages:', 'joly' ) . '</span>',
						'after'       => '</div>',
						'link_before' => '<span>',
						'link_after'  => '</span>',
						'pagelink'    => '<span class="screen-reader-text">' . esc_html__( 'Page', 'joly' ) . ' </span>%',
						'separator'   => '<span class="screen-reader-text">, </span>',
					)
				);
			} else {
				// Post content area
				joly_show_post_content( $joly_template_args, '<div class="post_content_inner">', '</div>' );
			}

			// More button
			if ( apply_filters( 'joly_filter_show_blog_readmore',  ! isset( $joly_template_args['more_button'] ) || ! empty( $joly_template_args['more_button'] ), 'excerpt' ) ) {
				if ( empty( $joly_template_args['no_links'] ) ) {
					do_action( 'joly_action_before_post_readmore' );
					if ( joly_get_theme_option( 'blog_content' ) != 'fullpost' ) {
						joly_show_post_more_link( $joly_template_args, '<p>', '</p>' );
					} else {
						joly_show_post_comments_link( $joly_template_args, '<p>', '</p>' );
					}
					do_action( 'joly_action_after_post_readmore' );
				}
			}

			?>
		</div><!-- .entry-content -->
		<?php
	}
	?>
</article>
<?php

if ( is_array( $joly_template_args ) ) {
	if ( ! empty( $joly_template_args['slider'] ) || $joly_columns > 1 ) {
		?>
		</div>
		<?php
	}
}
