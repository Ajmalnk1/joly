<?php
/**
 * The template to display the site logo in the footer
 *
 * @package JOLY
 * @since JOLY 1.0.10
 */

// Logo
if ( joly_is_on( joly_get_theme_option( 'logo_in_footer' ) ) ) {
	$joly_logo_image = joly_get_logo_image( 'footer' );
	$joly_logo_text  = get_bloginfo( 'name' );
	if ( ! empty( $joly_logo_image['logo'] ) || ! empty( $joly_logo_text ) ) {
		?>
		<div class="footer_logo_wrap">
			<div class="footer_logo_inner">
				<?php
				if ( ! empty( $joly_logo_image['logo'] ) ) {
					$joly_attr = joly_getimagesize( $joly_logo_image['logo'] );
					echo '<a href="' . esc_url( home_url( '/' ) ) . '">'
							. '<img src="' . esc_url( $joly_logo_image['logo'] ) . '"'
								. ( ! empty( $joly_logo_image['logo_retina'] ) ? ' srcset="' . esc_url( $joly_logo_image['logo_retina'] ) . ' 2x"' : '' )
								. ' class="logo_footer_image"'
								. ' alt="' . esc_attr__( 'Site logo', 'joly' ) . '"'
								. ( ! empty( $joly_attr[3] ) ? ' ' . wp_kses_data( $joly_attr[3] ) : '' )
							. '>'
						. '</a>';
				} elseif ( ! empty( $joly_logo_text ) ) {
					echo '<h1 class="logo_footer_text">'
							. '<a href="' . esc_url( home_url( '/' ) ) . '">'
								. esc_html( $joly_logo_text )
							. '</a>'
						. '</h1>';
				}
				?>
			</div>
		</div>
		<?php
	}
}
