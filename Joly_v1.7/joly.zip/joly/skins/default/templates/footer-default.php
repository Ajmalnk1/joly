<?php
/**
 * The template to display default site footer
 *
 * @package JOLY
 * @since JOLY 1.0.10
 */

?>
<footer class="footer_wrap footer_default
<?php
$joly_footer_scheme = joly_get_theme_option( 'footer_scheme' );
if ( ! empty( $joly_footer_scheme ) && ! joly_is_inherit( $joly_footer_scheme  ) ) {
	echo ' scheme_' . esc_attr( $joly_footer_scheme );
}
?>
				">
	<?php

	// Footer widgets area
	get_template_part( apply_filters( 'joly_filter_get_template_part', 'templates/footer-widgets' ) );

	// Logo
	get_template_part( apply_filters( 'joly_filter_get_template_part', 'templates/footer-logo' ) );

	// Socials
	get_template_part( apply_filters( 'joly_filter_get_template_part', 'templates/footer-socials' ) );

	// Copyright area
	get_template_part( apply_filters( 'joly_filter_get_template_part', 'templates/footer-copyright' ) );

	?>
</footer><!-- /.footer_wrap -->
