<?php
/**
 * The template to display the widgets area in the footer
 *
 * @package JOLY
 * @since JOLY 1.0.10
 */

// Footer sidebar
$joly_footer_name    = joly_get_theme_option( 'footer_widgets' );
$joly_footer_present = ! joly_is_off( $joly_footer_name ) && is_active_sidebar( $joly_footer_name );
if ( $joly_footer_present ) {
	joly_storage_set( 'current_sidebar', 'footer' );
	$joly_footer_wide = joly_get_theme_option( 'footer_wide' );
	ob_start();
	if ( is_active_sidebar( $joly_footer_name ) ) {
		dynamic_sidebar( $joly_footer_name );
	}
	$joly_out = trim( ob_get_contents() );
	ob_end_clean();
	if ( ! empty( $joly_out ) ) {
		$joly_out          = preg_replace( "/<\\/aside>[\r\n\s]*<aside/", '</aside><aside', $joly_out );
		$joly_need_columns = true;   //or check: strpos($joly_out, 'columns_wrap')===false;
		if ( $joly_need_columns ) {
			$joly_columns = max( 0, (int) joly_get_theme_option( 'footer_columns' ) );			
			if ( 0 == $joly_columns ) {
				$joly_columns = min( 4, max( 1, joly_tags_count( $joly_out, 'aside' ) ) );
			}
			if ( $joly_columns > 1 ) {
				$joly_out = preg_replace( '/<aside([^>]*)class="widget/', '<aside$1class="column-1_' . esc_attr( $joly_columns ) . ' widget', $joly_out );
			} else {
				$joly_need_columns = false;
			}
		}
		?>
		<div class="footer_widgets_wrap widget_area<?php echo ! empty( $joly_footer_wide ) ? ' footer_fullwidth' : ''; ?> sc_layouts_row sc_layouts_row_type_normal">
			<?php do_action( 'joly_action_before_sidebar_wrap', 'footer' ); ?>
			<div class="footer_widgets_inner widget_area_inner">
				<?php
				if ( ! $joly_footer_wide ) {
					?>
					<div class="content_wrap">
					<?php
				}
				if ( $joly_need_columns ) {
					?>
					<div class="columns_wrap">
					<?php
				}
				do_action( 'joly_action_before_sidebar', 'footer' );
				joly_show_layout( $joly_out );
				do_action( 'joly_action_after_sidebar', 'footer' );
				if ( $joly_need_columns ) {
					?>
					</div><!-- /.columns_wrap -->
					<?php
				}
				if ( ! $joly_footer_wide ) {
					?>
					</div><!-- /.content_wrap -->
					<?php
				}
				?>
			</div><!-- /.footer_widgets_inner -->
			<?php do_action( 'joly_action_after_sidebar_wrap', 'footer' ); ?>
		</div><!-- /.footer_widgets_wrap -->
		<?php
	}
}
