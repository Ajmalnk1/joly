<?php
/**
 * The template to display the socials in the footer
 *
 * @package JOLY
 * @since JOLY 1.0.10
 */


// Socials
if ( joly_is_on( joly_get_theme_option( 'socials_in_footer' ) ) ) {
	$joly_output = joly_get_socials_links();
	if ( '' != $joly_output ) {
		?>
		<div class="footer_socials_wrap socials_wrap">
			<div class="footer_socials_inner">
				<?php joly_show_layout( $joly_output ); ?>
			</div>
		</div>
		<?php
	}
}
