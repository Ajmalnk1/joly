<?php
/**
 * The Portfolio template to display the content
 *
 * Used for index/archive/search.
 *
 * @package JOLY
 * @since JOLY 1.0
 */

$joly_template_args = get_query_var( 'joly_template_args' );
if ( is_array( $joly_template_args ) ) {
	$joly_columns    = empty( $joly_template_args['columns'] ) ? 2 : max( 1, $joly_template_args['columns'] );
	$joly_blog_style = array( $joly_template_args['type'], $joly_columns );
    $joly_columns_class = joly_get_column_class( 1, $joly_columns, ! empty( $joly_template_args['columns_tablet']) ? $joly_template_args['columns_tablet'] : '', ! empty($joly_template_args['columns_mobile']) ? $joly_template_args['columns_mobile'] : '' );
} else {
	$joly_blog_style = explode( '_', joly_get_theme_option( 'blog_style' ) );
	$joly_columns    = empty( $joly_blog_style[1] ) ? 2 : max( 1, $joly_blog_style[1] );
    $joly_columns_class = joly_get_column_class( 1, $joly_columns );
}

$joly_post_format = get_post_format();
$joly_post_format = empty( $joly_post_format ) ? 'standard' : str_replace( 'post-format-', '', $joly_post_format );

?><div class="
<?php
if ( ! empty( $joly_template_args['slider'] ) ) {
	echo ' slider-slide swiper-slide';
} else {
	echo ( joly_is_blog_style_use_masonry( $joly_blog_style[0] ) ? 'masonry_item masonry_item-1_' . esc_attr( $joly_columns ) : esc_attr( $joly_columns_class ));
}
?>
"><article id="post-<?php the_ID(); ?>" 
	<?php
	post_class(
		'post_item post_item_container post_format_' . esc_attr( $joly_post_format )
		. ' post_layout_portfolio'
		. ' post_layout_portfolio_' . esc_attr( $joly_columns )
		. ( 'portfolio' != $joly_blog_style[0] ? ' ' . esc_attr( $joly_blog_style[0] )  . '_' . esc_attr( $joly_columns ) : '' )
	);
	joly_add_blog_animation( $joly_template_args );
	?>
>
<?php

	// Sticky label
	if ( is_sticky() && ! is_paged() ) {
		?>
		<span class="post_label label_sticky"></span>
		<?php
	}

	$joly_hover   = ! empty( $joly_template_args['hover'] ) && ! joly_is_inherit( $joly_template_args['hover'] )
								? $joly_template_args['hover']
								: joly_get_theme_option( 'image_hover' );

	if ( 'dots' == $joly_hover ) {
		$joly_post_link = empty( $joly_template_args['no_links'] )
								? ( ! empty( $joly_template_args['link'] )
									? $joly_template_args['link']
									: get_permalink()
									)
								: '';
		$joly_target    = ! empty( $joly_post_link ) && false === strpos( $joly_post_link, home_url() )
								? ' target="_blank" rel="nofollow"'
								: '';
	}
	
	// Meta parts
	$joly_components = ! empty( $joly_template_args['meta_parts'] )
							? ( is_array( $joly_template_args['meta_parts'] )
								? $joly_template_args['meta_parts']
								: explode( ',', $joly_template_args['meta_parts'] )
								)
							: joly_array_get_keys_by_value( joly_get_theme_option( 'meta_parts' ) );

	// Featured image
	joly_show_post_featured( apply_filters( 'joly_filter_args_featured',
        array(
			'hover'         => $joly_hover,
			'no_links'      => ! empty( $joly_template_args['no_links'] ),
			'thumb_size'    => ! empty( $joly_template_args['thumb_size'] )
								? $joly_template_args['thumb_size']
								: joly_get_thumb_size(
									joly_is_blog_style_use_masonry( $joly_blog_style[0] )
										? (	strpos( joly_get_theme_option( 'body_style' ), 'full' ) !== false || $joly_columns < 3
											? 'masonry-big'
											: 'masonry'
											)
										: (	strpos( joly_get_theme_option( 'body_style' ), 'full' ) !== false || $joly_columns < 3
											? 'square'
											: 'square'
											)
								),
			'thumb_bg' => joly_is_blog_style_use_masonry( $joly_blog_style[0] ) ? false : true,
			'show_no_image' => true,
			'meta_parts'    => $joly_components,
			'class'         => 'dots' == $joly_hover ? 'hover_with_info' : '',
			'post_info'     => 'dots' == $joly_hover
										? '<div class="post_info"><h5 class="post_title">'
											. ( ! empty( $joly_post_link )
												? '<a href="' . esc_url( $joly_post_link ) . '"' . ( ! empty( $target ) ? $target : '' ) . '>'
												: ''
												)
												. esc_html( get_the_title() ) 
											. ( ! empty( $joly_post_link )
												? '</a>'
												: ''
												)
											. '</h5></div>'
										: '',
            'thumb_ratio'   => 'info' == $joly_hover ?  '100:102' : '',
        ),
        'content-portfolio',
        $joly_template_args
    ) );
	?>
</article></div><?php
// Need opening PHP-tag above, because <article> is a inline-block element (used as column)!