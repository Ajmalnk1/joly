<?php
/**
 * The template to display custom header from the ThemeREX Addons Layouts
 *
 * @package JOLY
 * @since JOLY 1.0.06
 */

$joly_header_css   = '';
$joly_header_image = get_header_image();
$joly_header_video = joly_get_header_video();
if ( ! empty( $joly_header_image ) && joly_trx_addons_featured_image_override( is_singular() || joly_storage_isset( 'blog_archive' ) || is_category() ) ) {
	$joly_header_image = joly_get_current_mode_image( $joly_header_image );
}

$joly_header_id = joly_get_custom_header_id();
$joly_header_meta = get_post_meta( $joly_header_id, 'trx_addons_options', true );
if ( ! empty( $joly_header_meta['margin'] ) ) {
	joly_add_inline_css( sprintf( '.page_content_wrap{padding-top:%s}', esc_attr( joly_prepare_css_value( $joly_header_meta['margin'] ) ) ) );
}

?><header class="top_panel top_panel_custom top_panel_custom_<?php echo esc_attr( $joly_header_id ); ?> top_panel_custom_<?php echo esc_attr( sanitize_title( get_the_title( $joly_header_id ) ) ); ?>
				<?php
				echo ! empty( $joly_header_image ) || ! empty( $joly_header_video )
					? ' with_bg_image'
					: ' without_bg_image';
				if ( '' != $joly_header_video ) {
					echo ' with_bg_video';
				}
				if ( '' != $joly_header_image ) {
					echo ' ' . esc_attr( joly_add_inline_css_class( 'background-image: url(' . esc_url( $joly_header_image ) . ');' ) );
				}
				if ( is_single() && has_post_thumbnail() ) {
					echo ' with_featured_image';
				}
				if ( joly_is_on( joly_get_theme_option( 'header_fullheight' ) ) ) {
					echo ' header_fullheight joly-full-height';
				}
				$joly_header_scheme = joly_get_theme_option( 'header_scheme' );
				if ( ! empty( $joly_header_scheme ) && ! joly_is_inherit( $joly_header_scheme  ) ) {
					echo ' scheme_' . esc_attr( $joly_header_scheme );
				}
				?>
">
	<?php

	// Background video
	if ( ! empty( $joly_header_video ) ) {
		get_template_part( apply_filters( 'joly_filter_get_template_part', 'templates/header-video' ) );
	}

	// Custom header's layout
	do_action( 'joly_action_show_layout', $joly_header_id );

	// Header widgets area
	get_template_part( apply_filters( 'joly_filter_get_template_part', 'templates/header-widgets' ) );

	?>
</header>
