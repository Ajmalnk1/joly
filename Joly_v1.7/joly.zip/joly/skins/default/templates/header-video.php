<?php
/**
 * The template to display the background video in the header
 *
 * @package JOLY
 * @since JOLY 1.0.14
 */
$joly_header_video = joly_get_header_video();
$joly_embed_video  = '';
if ( ! empty( $joly_header_video ) && ! joly_is_from_uploads( $joly_header_video ) ) {
	if ( joly_is_youtube_url( $joly_header_video ) && preg_match( '/[=\/]([^=\/]*)$/', $joly_header_video, $matches ) && ! empty( $matches[1] ) ) {
		?><div id="background_video" data-youtube-code="<?php echo esc_attr( $matches[1] ); ?>"></div>
		<?php
	} else {
		?>
		<div id="background_video"><?php joly_show_layout( joly_get_embed_video( $joly_header_video ) ); ?></div>
		<?php
	}
}
