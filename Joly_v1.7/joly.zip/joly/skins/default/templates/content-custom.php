<?php
/**
 * The custom template to display the content
 *
 * Used for index/archive/search.
 *
 * @package JOLY
 * @since JOLY 1.0.50
 */

$joly_template_args = get_query_var( 'joly_template_args' );
if ( is_array( $joly_template_args ) ) {
	$joly_columns    = empty( $joly_template_args['columns'] ) ? 2 : max( 1, $joly_template_args['columns'] );
	$joly_blog_style = array( $joly_template_args['type'], $joly_columns );
} else {
	$joly_blog_style = explode( '_', joly_get_theme_option( 'blog_style' ) );
	$joly_columns    = empty( $joly_blog_style[1] ) ? 2 : max( 1, $joly_blog_style[1] );
}
$joly_blog_id       = joly_get_custom_blog_id( join( '_', $joly_blog_style ) );
$joly_blog_style[0] = str_replace( 'blog-custom-', '', $joly_blog_style[0] );
$joly_expanded      = ! joly_sidebar_present() && joly_get_theme_option( 'expand_content' ) == 'expand';
$joly_components    = ! empty( $joly_template_args['meta_parts'] )
							? ( is_array( $joly_template_args['meta_parts'] )
								? join( ',', $joly_template_args['meta_parts'] )
								: $joly_template_args['meta_parts']
								)
							: joly_array_get_keys_by_value( joly_get_theme_option( 'meta_parts' ) );
$joly_post_format   = get_post_format();
$joly_post_format   = empty( $joly_post_format ) ? 'standard' : str_replace( 'post-format-', '', $joly_post_format );

$joly_blog_meta     = joly_get_custom_layout_meta( $joly_blog_id );
$joly_custom_style  = ! empty( $joly_blog_meta['scripts_required'] ) ? $joly_blog_meta['scripts_required'] : 'none';

if ( ! empty( $joly_template_args['slider'] ) || $joly_columns > 1 || ! joly_is_off( $joly_custom_style ) ) {
	?><div class="
		<?php
		if ( ! empty( $joly_template_args['slider'] ) ) {
			echo 'slider-slide swiper-slide';
		} else {
			echo esc_attr( ( joly_is_off( $joly_custom_style ) ? 'column' : sprintf( '%1$s_item %1$s_item', $joly_custom_style ) ) . "-1_{$joly_columns}" );
		}
		?>
	">
	<?php
}
?>
<article id="post-<?php the_ID(); ?>" data-post-id="<?php the_ID(); ?>"
	<?php
	post_class(
			'post_item post_item_container post_format_' . esc_attr( $joly_post_format )
					. ' post_layout_custom post_layout_custom_' . esc_attr( $joly_columns )
					. ' post_layout_' . esc_attr( $joly_blog_style[0] )
					. ' post_layout_' . esc_attr( $joly_blog_style[0] ) . '_' . esc_attr( $joly_columns )
					. ( ! joly_is_off( $joly_custom_style )
						? ' post_layout_' . esc_attr( $joly_custom_style )
							. ' post_layout_' . esc_attr( $joly_custom_style ) . '_' . esc_attr( $joly_columns )
						: ''
						)
		);
	joly_add_blog_animation( $joly_template_args );
	?>
>
	<?php
	// Sticky label
	if ( is_sticky() && ! is_paged() ) {
		?>
		<span class="post_label label_sticky"></span>
		<?php
	}
	// Custom layout
	do_action( 'joly_action_show_layout', $joly_blog_id, get_the_ID() );
	?>
</article><?php
if ( ! empty( $joly_template_args['slider'] ) || $joly_columns > 1 || ! joly_is_off( $joly_custom_style ) ) {
	?></div><?php
	// Need opening PHP-tag above just after </div>, because <div> is a inline-block element (used as column)!
}
