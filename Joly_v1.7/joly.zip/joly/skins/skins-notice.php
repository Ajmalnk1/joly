<?php
/**
 * The template to display Admin notices
 *
 * @package JOLY
 * @since JOLY 1.0.64
 */

$joly_skins_url  = get_admin_url( null, 'admin.php?page=trx_addons_theme_panel#trx_addons_theme_panel_section_skins' );
$joly_skins_args = get_query_var( 'joly_skins_notice_args' );
?>
<div class="joly_admin_notice joly_skins_notice notice notice-info is-dismissible" data-notice="skins">
	<?php
	// Theme image
	$joly_theme_img = joly_get_file_url( 'screenshot.jpg' );
	if ( '' != $joly_theme_img ) {
		?>
		<div class="joly_notice_image"><img src="<?php echo esc_url( $joly_theme_img ); ?>" alt="<?php esc_attr_e( 'Theme screenshot', 'joly' ); ?>"></div>
		<?php
	}

	// Title
	?>
	<h3 class="joly_notice_title">
		<?php esc_html_e( 'New skins available', 'joly' ); ?>
	</h3>
	<?php

	// Description
	$joly_total      = $joly_skins_args['update'];	// Store value to the separate variable to avoid warnings from ThemeCheck plugin!
	$joly_skins_msg  = $joly_total > 0
							// Translators: Add new skins number
							? '<strong>' . sprintf( _n( '%d new version', '%d new versions', $joly_total, 'joly' ), $joly_total ) . '</strong>'
							: '';
	$joly_total      = $joly_skins_args['free'];
	$joly_skins_msg .= $joly_total > 0
							? ( ! empty( $joly_skins_msg ) ? ' ' . esc_html__( 'and', 'joly' ) . ' ' : '' )
								// Translators: Add new skins number
								. '<strong>' . sprintf( _n( '%d free skin', '%d free skins', $joly_total, 'joly' ), $joly_total ) . '</strong>'
							: '';
	$joly_total      = $joly_skins_args['pay'];
	$joly_skins_msg .= $joly_skins_args['pay'] > 0
							? ( ! empty( $joly_skins_msg ) ? ' ' . esc_html__( 'and', 'joly' ) . ' ' : '' )
								// Translators: Add new skins number
								. '<strong>' . sprintf( _n( '%d paid skin', '%d paid skins', $joly_total, 'joly' ), $joly_total ) . '</strong>'
							: '';
	?>
	<div class="joly_notice_text">
		<p>
			<?php
			// Translators: Add new skins info
			echo wp_kses_data( sprintf( __( "We are pleased to announce that %s are available for your theme", 'joly' ), $joly_skins_msg ) );
			?>
		</p>
	</div>
	<?php

	// Buttons
	?>
	<div class="joly_notice_buttons">
		<?php
		// Link to the theme dashboard page
		?>
		<a href="<?php echo esc_url( $joly_skins_url ); ?>" class="button button-primary"><i class="dashicons dashicons-update"></i> 
			<?php
			// Translators: Add theme name
			esc_html_e( 'Go to Skins manager', 'joly' );
			?>
		</a>
	</div>
</div>
