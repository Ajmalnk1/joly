<?php
/**
 * The template to display Admin notices
 *
 * @package JOLY
 * @since JOLY 1.98.0
 */

$joly_skins_url   = get_admin_url( null, 'admin.php?page=trx_addons_theme_panel#trx_addons_theme_panel_section_skins' );
$joly_active_skin = joly_skins_get_active_skin_name();
?>
<div class="joly_admin_notice joly_skins_notice notice notice-error">
	<?php
	// Theme image
	$joly_theme_img = joly_get_file_url( 'screenshot.jpg' );
	if ( '' != $joly_theme_img ) {
		?>
		<div class="joly_notice_image"><img src="<?php echo esc_url( $joly_theme_img ); ?>" alt="<?php esc_attr_e( 'Theme screenshot', 'joly' ); ?>"></div>
		<?php
	}

	// Title
	?>
	<h3 class="joly_notice_title">
		<?php esc_html_e( 'Active skin is missing!', 'joly' ); ?>
	</h3>
	<div class="joly_notice_text">
		<p>
			<?php
			// Translators: Add a current skin name to the message
			echo wp_kses_data( sprintf( __( "Your active skin <b>'%s'</b> is missing. Usually this happens when the theme is updated directly through the server or FTP.", 'joly' ), ucfirst( $joly_active_skin ) ) );
			?>
		</p>
		<p>
			<?php
			echo wp_kses_data( __( "Please use only <b>'ThemeREX Updater v.1.6.0+'</b> plugin for your future updates.", 'joly' ) );
			?>
		</p>
		<p>
			<?php
			echo wp_kses_data( __( "But no worries! You can re-download the skin via 'Skins Manager' ( Theme Panel - Theme Dashboard - Skins ).", 'joly' ) );
			?>
		</p>
	</div>
	<?php

	// Buttons
	?>
	<div class="joly_notice_buttons">
		<?php
		// Link to the theme dashboard page
		?>
		<a href="<?php echo esc_url( $joly_skins_url ); ?>" class="button button-primary"><i class="dashicons dashicons-update"></i> 
			<?php
			// Translators: Add theme name
			esc_html_e( 'Go to Skins manager', 'joly' );
			?>
		</a>
	</div>
</div>
