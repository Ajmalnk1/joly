<?php
/**
 * The Sidebar containing the main widget areas.
 *
 * @package JOLY
 * @since JOLY 1.0
 */

if ( joly_sidebar_present() ) {
	
	$joly_sidebar_type = joly_get_theme_option( 'sidebar_type' );
	if ( 'custom' == $joly_sidebar_type && ! joly_is_layouts_available() ) {
		$joly_sidebar_type = 'default';
	}
	
	// Catch output to the buffer
	ob_start();
	if ( 'default' == $joly_sidebar_type ) {
		// Default sidebar with widgets
		$joly_sidebar_name = joly_get_theme_option( 'sidebar_widgets' );
		joly_storage_set( 'current_sidebar', 'sidebar' );
		if ( is_active_sidebar( $joly_sidebar_name ) ) {
			dynamic_sidebar( $joly_sidebar_name );
		}
	} else {
		// Custom sidebar from Layouts Builder
		$joly_sidebar_id = joly_get_custom_sidebar_id();
		do_action( 'joly_action_show_layout', $joly_sidebar_id );
	}
	$joly_out = trim( ob_get_contents() );
	ob_end_clean();
	
	// If any html is present - display it
	if ( ! empty( $joly_out ) ) {
		$joly_sidebar_position    = joly_get_theme_option( 'sidebar_position' );
		$joly_sidebar_position_ss = joly_get_theme_option( 'sidebar_position_ss' );
		?>
		<div class="sidebar widget_area
			<?php
			echo ' ' . esc_attr( $joly_sidebar_position );
			echo ' sidebar_' . esc_attr( $joly_sidebar_position_ss );
			echo ' sidebar_' . esc_attr( $joly_sidebar_type );

			$joly_sidebar_scheme = apply_filters( 'joly_filter_sidebar_scheme', joly_get_theme_option( 'sidebar_scheme' ) );
			if ( ! empty( $joly_sidebar_scheme ) && ! joly_is_inherit( $joly_sidebar_scheme ) && 'custom' != $joly_sidebar_type ) {
				echo ' scheme_' . esc_attr( $joly_sidebar_scheme );
			}
			?>
		" role="complementary">
			<?php

			// Skip link anchor to fast access to the sidebar from keyboard
			?>
			<a id="sidebar_skip_link_anchor" class="joly_skip_link_anchor" href="#"></a>
			<?php

			do_action( 'joly_action_before_sidebar_wrap', 'sidebar' );

			// Button to show/hide sidebar on mobile
			if ( in_array( $joly_sidebar_position_ss, array( 'above', 'float' ) ) ) {
				$joly_title = apply_filters( 'joly_filter_sidebar_control_title', 'float' == $joly_sidebar_position_ss ? esc_html__( 'Show Sidebar', 'joly' ) : '' );
				$joly_text  = apply_filters( 'joly_filter_sidebar_control_text', 'above' == $joly_sidebar_position_ss ? esc_html__( 'Show Sidebar', 'joly' ) : '' );
				?>
				<a href="#" class="sidebar_control" title="<?php echo esc_attr( $joly_title ); ?>"><?php echo esc_html( $joly_text ); ?></a>
				<?php
			}
			?>
			<div class="sidebar_inner">
				<?php
				do_action( 'joly_action_before_sidebar', 'sidebar' );
				joly_show_layout( preg_replace( "/<\/aside>[\r\n\s]*<aside/", '</aside><aside', $joly_out ) );
				do_action( 'joly_action_after_sidebar', 'sidebar' );
				?>
			</div>
			<?php

			do_action( 'joly_action_after_sidebar_wrap', 'sidebar' );

			?>
		</div>
		<div class="clearfix"></div>
		<?php
	}
}
